/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaWebCssTest;

import javafx.application.Application;
import javafx.stage.Stage;
/**
 *
 * @author mimik
 */
public class Main  extends Application{

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) 
    {
        Application.launch(args);
    }
    
    @Override
    public void start(final Stage stage)  {
                     
        
        NewApplication appForm = new NewApplication();
        appForm.setSize(800, 600);
        appForm.setVisible(true);
      
        
    }
    
}
